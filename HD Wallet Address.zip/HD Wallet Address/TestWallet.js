var http = require('http');
const bip39=require('bip39');
const hdkey=require('hdkey');
//Ethereum
const ethUtil=require('ethereumjs-util');
//Bitcoin
const hashlib = require('create-hash');
const btcLib = require('bitcoinjs-lib');
const bs58check = require('bs58check');

const ecc=require('eosjs-ecc');
const wif=require('wif');

http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/plain'});
    
    var password='';
        /* Calculate the strength for number of mnemonic words and create mnemonic words */
        var numWords = 15;
        var strength = numWords / 3 * 32;
       var mnemonic=bip39.generateMnemonic(strength);
       
        var seed = bip39.mnemonicToSeed(mnemonic,password);
        var seedhex=seed.toString('hex')
        const root = hdkey.fromMasterSeed(seed);
        const masterPrivateKey = root.privateKey.toString('hex');
        res.write("mnemonic"+mnemonic);
        res.write("\n");
      
        /* Ethereum Address Generation  */
        const ethaddress=GenerateEthAddress(root);
            res.write("\n Ethereum: "+ethaddress);

        /* Bitcoin Address Generation */
        const btcaddress=GenerateBtcAddress(root);
        res.write("\n Bitcoin : "+btcaddress);
        /* Litecoin Address Generation */
        const ltcaddress=GenerateLtcAddress(root);
        res.write("\n Litecoin : "+ltcaddress);
         /* BitcoinCash Address Generation */
         const BCHaddress=GenerateBchAddress(root);
         res.write("\n Bitcoin Cash : "+BCHaddress);

          /* EOS Address Generation */
          const Eosaddress=GenerateEosAddress(root);
          res.write("\n EOS : "+Eosaddress);
         
          /*Faucet Address */
          const ff=faucet();
          res.write("\n Harish : "+ff);

         res.end("\n End");

    
}

).listen(8080);
function GenerateEthAddress(root)
{
     var newchild=root.derive("m/44'/60'/0'/0/0");
        var chldprv=newchild.privateKey.toString('hex');
        var chldadd=ethUtil.privateToAddress(newchild.privateKey).toString('hex');
        var chksm=ethUtil.toChecksumAddress(chldadd);
       return chksm;
}

function GenerateBtcAddress(root)
{
    var btcChild=root.derive("m/44'/00'/0'/0/0");
    const btccHldPubkey = btcChild.publicKey;
    const shHash = hashlib('sha256').update(btccHldPubkey).digest();
    const rpmdhash = hashlib('rmd160').update(shHash).digest();

    var step4 = Buffer.allocUnsafe(21);
    /* Mainnet pubKeyHash: 0x00, Testnet pubKeyHash: 0x6f */
    step4.writeUInt8(0x6f, 0);
    rpmdhash.copy(step4, 1); //step4 now holds the extended RIPMD-160 result
    const btcadd = bs58check.encode(step4);
    return btcadd;
}
function GenerateLtcAddress(root)
{
    var ltcChild=root.derive("m/44'/02'/0'/0/0");
    const ltccHldPubkey = ltcChild.publicKey;
    const shHash = hashlib('sha256').update(ltccHldPubkey).digest();
    const rpmdhash = hashlib('rmd160').update(shHash).digest();

    var step4 = Buffer.allocUnsafe(21);
    /* Mainnet pubKeyHash: 0x30, Testnet pubKeyHash: 0x6f */
    step4.writeUInt8(0x6f, 0);
    rpmdhash.copy(step4, 1); //step4 now holds the extended RIPMD-160 result
     const ltcadd = bs58check.encode(step4);
     return ltcadd; 
}
function GenerateBchAddress(root)
{
    var BchChild=root.derive("m/44'/145'/0'/0/0");
    const BchcHldPubkey = BchChild.publicKey;
    const shHash = hashlib('sha256').update(BchcHldPubkey).digest();
    const rpmdhash = hashlib('rmd160').update(shHash).digest();

    var step4 = Buffer.allocUnsafe(21);
    /* Mainnet pubKeyHash: 0x30, Testnet pubKeyHash: 0x6f */
    step4.writeUInt8(0x6f, 0);
    rpmdhash.copy(step4, 1); //step4 now holds the extended RIPMD-160 result
     const Bchadd = bs58check.encode(step4);
     return Bchadd; 
}
function GenerateEosAddress(root)
{
    var EosChild=root.derive("m/44'/194'/0'/0/0");
    var eosChldpubKey=ecc.PublicKey(EosChild.publicKey).toString();
    var eosChldprvKey=wif.encode(128, EosChild.privateKey, false);
    validateEos(eosChldpubKey,eosChldprvKey);
    console.log(eosChldprvKey);
    return eosChldpubKey;
}
function validateEos(pubkey,prvkey)
{
console.log("Is valid public : " + ecc.isValidPublic(pubkey));
console.log("Is valid Private : "+ecc.isValidPrivate(prvkey));
}

function faucet()
{
const { address } = btcLib.payments.p2pkh({ pubkey: btcLib.ECPair.makeRandom().publicKey });
return address;
}